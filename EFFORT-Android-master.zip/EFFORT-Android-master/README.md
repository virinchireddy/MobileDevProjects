EFFORT-Android
==============
