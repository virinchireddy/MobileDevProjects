package in.spoors.effort1;

public interface RefreshListener {
	void onRefresh();
}
