package in.spoors.effort1;

public class AssignRouteDetailFragment {

}
